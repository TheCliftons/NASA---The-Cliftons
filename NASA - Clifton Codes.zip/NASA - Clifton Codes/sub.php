﻿<?php
if(isset($_POST["submit"]))

{
error_reporting(E_ERROR | E_WARNING | E_PARSE);
$server="localhost";
$username="root";
$pass="";
$datatbase="clifton";
$conn= new mysqli($server,$username,$pass,$datatbase);

$name = $_POST['name'];
$mobile=$_POST["mobile"];
$email=$_POST["email"];
$username=$_POST["username"];
$password=$_POST["password"];

if (mysqli_connect_error())
{
    die('Connect Error ('.mysqli_connect_errno().')'.mysqli_connect_error());

}
else 
{

$sql="insert into login(name,mobile,email,username,password) values('$name','$mobile','$email','$username','$password')";




    if($conn->query($sql))

    {
        
        
       echo '<script language="javascript">';
    echo 'location.href="Login.html"';
    echo '</script>';
   
 }
    else{
        echo "Error: ".$sql."<br>".$conn->error ;
    }
}



}
if(isset($_POST['login'])){

$server="localhost";
$username="root";
$pass="";
$datatbase="clifton";
$conn= new mysqli($server,$username,$pass,$datatbase);


$username=$_POST["username"];
$password=$_POST["password"];
$sql = "SELECT id FROM login WHERE username = '$username' and password = '$password'";
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  
  $result = $conn->query($sql);
  if ($result->num_rows > 0){
    echo '<script language="javascript">';
    echo 'location.href="index.html"';
    echo '</script>';
  }
  else{
    echo '<script language="javascript">';
    echo 'location.href="Login.html"';
    echo '</script>';
  }

}

?>

